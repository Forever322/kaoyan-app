const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./app-B6C2wD0M.js","./utils-DArJcFMw.js","./data-BD81yRGS.js"])))=>i.map(i=>d[i]);
import"./modulepreload-polyfill-Dezn_h7o.js";function e(){return`
    <section id="homeScreen" class="app-screen home-screen is-active" aria-label="为你推荐">
      <header class="home-header">
        <button class="home-brand" type="button" data-open-filter aria-label="打开筛选">
          <span class="brand-mark" aria-hidden="true">♫</span>
          <span><b>考研择校</b><small>YOUR EXAM RHYTHM</small></span>
        </button>
        <button class="profile-orb" type="button" data-open-filter aria-label="筛选与搜索">♙</button>
      </header>

      <main class="home-main">
        <div class="home-greeting"><span>晚上好，研友</span><em>2026 研考</em></div>
        <h1>把分数调成你的节奏</h1>

        <section class="score-dashboard" aria-labelledby="homeScoreHeading">
          <div class="score-dashboard-top"><span id="homeScoreHeading">我的初试分数</span><b id="homeScoreState">状态正热</b></div>
          <p id="homeLineStatus" class="home-line-status">✓ 超过 A 区工学线 124 分</p>
          <div class="home-score-row"><input id="scoreInput" type="number" min="0" max="500" inputmode="numeric" value="" aria-label="你的初试分数"><span>分</span><small id="homeScoreNote">已为你准备好 32 所院校</small></div>
          <div class="score-equalizer" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
        </section>

        <div class="home-condition-chips" aria-label="当前匹配条件">
          <button type="button" data-open-filter id="homeDegreeChip">♧ 学硕</button>
          <button type="button" data-open-filter id="homeCategoryChip">♙ 工学</button>
          <button type="button" data-open-filter id="homeZoneChip">⌾ A 区</button>
        </div>

        <button id="searchBtn" class="home-match-btn" type="button"><span><b>开始匹配院校</b><small>基于分数、专业与地区</small></span><i>→</i></button>

        <div class="home-section-heading"><h2>专为你上新的院校</h2><button id="homeSeeAllBtn" type="button">查看全部 ›</button></div>
        <button id="homeRecommendCard" class="home-recommend-card" type="button" data-uni-name="清华大学">
          <span class="home-recommend-copy"><b id="homeRecommendName">清华大学</b><small id="homeRecommendMeta">工学 · 学硕 · A区 · 全日制</small><em id="homeRecommendScore">近 4 年院线 303 — 325 分</em></span>
          <span class="home-recommend-badges"><i id="homeRecommendLevel">985</i><strong id="homeRecommendVerdict">稳过</strong></span>
          <span class="recommend-meter"><i id="homeRecommendMeter"></i></span>
        </button>
      </main>

      <!-- 真实表单状态由筛选抽屉编辑；保留控件以复用现有匹配逻辑。 -->
      <div class="home-logic-controls" aria-hidden="true">
        <div id="degreeToggle"><button class="toggle-btn active" type="button" data-value="xueshuo">学硕</button><button class="toggle-btn" type="button" data-value="zhuanshuo">专硕</button></div>
        <div id="categorySelect" class="major-dropdown"><div class="major-trigger" role="combobox" aria-expanded="false" aria-haspopup="listbox"><input type="text" class="major-trigger-input" autocomplete="off" readonly><svg class="major-trigger-icon" width="12" height="12" viewBox="0 0 12 12"><path fill="currentColor" d="M6 8L1 3h10z"/></svg></div><div class="major-panel" role="listbox"></div></div>
        <div id="majorGroup"><label id="majorLabel">专业方向</label><div id="majorSelect" class="major-dropdown"><div class="major-trigger" role="combobox" aria-expanded="false" aria-haspopup="listbox"><input type="text" class="major-trigger-input" autocomplete="off" readonly><svg class="major-trigger-icon" width="12" height="12" viewBox="0 0 12 12"><path fill="currentColor" d="M6 8L1 3h10z"/></svg></div><div class="major-panel" role="listbox"></div></div></div>
        <div id="zoneToggle"><button class="toggle-btn active" type="button" data-value="A">A区</button><button class="toggle-btn" type="button" data-value="B">B区</button><button class="toggle-btn" type="button" data-value="all">不限</button></div>
        <select id="provinceSelect"><option value="all">全部省份</option></select>
        <div id="studyModeToggle"><button class="toggle-btn active" type="button" data-value="all">全部</button><button class="toggle-btn" type="button" data-value="全日制">全日制</button><button class="toggle-btn" type="button" data-value="非全日制">非全日制</button></div>
        <section id="nationalLineCard"><div id="nationalLineInfo"></div></section>
      </div>
    </section>
  `}function t(){return`
    <section id="resultsScreen" class="app-screen results-screen" aria-label="匹配结果">
      <header class="screen-topbar">
        <button id="resultsBackBtn" class="round-nav-btn" type="button" aria-label="返回首页">←</button>
        <h1>匹配结果</h1>
        <button id="resultsFilterBtn" class="round-nav-btn is-lime" type="button" aria-label="调整筛选">☷</button>
      </header>
      <main id="resultsSection" class="results-main" aria-live="polite">
        <button id="resultContext" class="result-context" type="button" aria-label="修改匹配条件"></button>
        <div class="results-title-row"><h2><strong id="resultCountNumber">0</strong> 所匹配院校</h2><select id="sortSelect" class="result-sort-select" aria-label="排序方式"><option value="default">综合排序</option><option value="level">院校层次</option><option value="match">匹配度</option></select></div>
        <section id="resultsNationalLine" class="results-national-line" aria-live="polite"></section>
        <div id="resultInsights" class="result-insights"></div>
        <div id="resultsList" class="results-list"></div>
      </main>
    </section>
  `}function n(){return`
    <section id="failScreen" class="app-screen fail-screen" aria-label="国家线提醒">
      <header class="screen-topbar">
        <button id="failBackBtn" class="round-nav-btn" type="button" aria-label="返回首页">←</button>
        <h1>国家线提醒</h1>
        <span class="screen-topbar-meta" id="failFilterMeta">学硕 · 工学</span>
      </header>
      <main class="fail-main">
        <section class="fail-hero" id="failState">
          <div class="fail-hero-top"><span id="failLineLabel">A 区工学国家线为 254 分</span><b id="failDiffBadge">差 6 分</b></div>
          <strong id="failScoreValue">248</strong><em>分</em>
          <p id="failMsg">别急，切换 B 区后仍有机会进入匹配池。</p>
        </section>
        <div class="fail-section-title"><h2>分区再判断</h2><span>同一专业 · 2026 年</span></div>
        <div id="failComparison" class="fail-comparison"></div>
        <button id="tryBZoneBtn" class="home-match-btn fail-match-btn" type="button"><span><b>切换至 B 区匹配</b><small id="failBZoneCount">院校等待加入你的歌单</small></span><i>→</i></button>
        <section class="fail-options"><h3>你还可以这样做</h3><ul><li>查看 B 区院校的城市与专业覆盖</li><li>修改专业方向，重新计算国家线</li><li>保存本次条件，作为调剂备选</li></ul></section>
      </main>
    </section>
  `}function r(){return`
    <div id="filterSheet" class="filter-sheet hidden" aria-hidden="true">
      <button id="filterSheetBackdrop" class="filter-sheet-backdrop" type="button" aria-label="关闭筛选器"></button>
      <div class="filter-context-copy" aria-hidden="true"><h1>考研择校</h1><p>输入分数，找到合适的院校</p></div>
      <section class="filter-sheet-panel" role="dialog" aria-modal="true" aria-labelledby="filterSheetTitle">
        <div class="sheet-handle" aria-hidden="true"></div>
        <div class="sheet-heading"><h2 id="filterSheetTitle"><i>☷</i> 筛选与搜索</h2><button id="closeFilterSheetBtn" class="sheet-close" type="button" aria-label="关闭">×</button></div>

        <label class="sheet-search-box"><i>⌕</i><input id="sheetUniSearch" type="search" placeholder="搜索院校、城市或省份"></label>
        <div id="sheetSearchMatches" class="sheet-search-matches" aria-live="polite"></div>
        <button id="sheetQuickUniversity" class="sheet-quick-university" type="button" data-uni-name="清华大学"><span>♜ 清华大学 · 985 · 北京</span><b>查看 ›</b></button>

        <p class="sheet-subhead">匹配条件</p>
        <label class="sheet-control-row"><span><i>▣</i> 初试总分</span><input id="sheetScoreInput" type="number" min="0" max="500" placeholder="输入分数" aria-label="初试总分"></label>
        <div class="sheet-option-section">
          <span class="sheet-option-label"><i>♧</i> 学位类型</span>
          <div id="sheetDegreeOptions" class="sheet-option-grid sheet-degree-options" role="radiogroup" aria-label="学位类型">
            <button type="button" data-value="xueshuo" role="radio">学硕</button>
            <button type="button" data-value="zhuanshuo" role="radio">专硕</button>
          </div>
          <select id="sheetDegreeSelect" class="sheet-select-source" tabindex="-1" aria-hidden="true"><option value="xueshuo">学硕</option><option value="zhuanshuo">专硕</option></select>
        </div>
        <div class="sheet-option-section">
          <span class="sheet-option-label"><i>♙</i> 学科门类</span>
          <div id="sheetCategoryOptions" class="sheet-option-grid sheet-category-options" role="radiogroup" aria-label="学科门类"></div>
          <select id="sheetCategorySelect" class="sheet-select-source" tabindex="-1" aria-hidden="true"></select>
        </div>
        <div class="sheet-option-section sheet-province-section">
          <div class="sheet-option-heading"><span class="sheet-option-label"><i>⌖</i> 省份筛选</span><button id="sheetProvinceExpandBtn" class="sheet-option-expand" type="button" aria-expanded="false"><b id="sheetProvinceCurrent">全部省份</b><i>⌄</i></button></div>
          <div id="sheetProvinceOptions" class="sheet-option-grid sheet-province-options" role="radiogroup" aria-label="省份筛选"></div>
          <select id="sheetProvinceSelect" class="sheet-select-source" tabindex="-1" aria-hidden="true"></select>
        </div>
        <div id="sheetMajorRow" class="sheet-control-row sheet-advanced-control"><span><i>⌁</i> 专业方向</span><div id="sheetMajorSelectDisplay" class="sheet-major-dropdown"><div class="sheet-major-trigger" role="combobox" aria-expanded="false" aria-haspopup="listbox" aria-controls="sheetMajorPanel"><input type="text" class="sheet-major-input" autocomplete="off" readonly aria-label="专业方向"></div><div id="sheetMajorPanel" class="sheet-major-panel" role="listbox"></div></div><select id="sheetMajorSelect" class="sheet-select-source" tabindex="-1" aria-hidden="true"></select></div>

        <div class="sheet-choice-group"><span>招生分区</span><div id="sheetZoneToggle" class="sheet-choice-row"><button type="button" data-value="A">A 区</button><button type="button" data-value="B">B 区</button><button type="button" data-value="all">不限</button></div></div>
        <div class="sheet-choice-group"><span>培养方式</span><div id="sheetStudyModeToggle" class="sheet-choice-row"><button type="button" data-value="all">全部</button><button type="button" data-value="全日制">全日制</button><button type="button" data-value="非全日制">非全日制</button></div></div>

        <button id="applyFilterSheetBtn" class="home-match-btn sheet-apply" type="button"><span><b>刷新匹配结果</b><small id="sheetMatchCount">预计显示 32 所院校</small></span><i>→</i></button>
        <button id="openDataManagerBtn" class="sheet-data-manager" type="button"><span>▣</span> 管理本地院校数据与导入导出 <b>›</b></button>
      </section>
    </div>
  `}function i(){return`
    <footer class="app-footer" aria-label="主导航">
      <span class="footer-active-pill" aria-hidden="true"></span>
      <button id="homeNavBtn" class="footer-btn footer-nav-btn active" type="button"><b>⌂</b><span>首页</span></button>
      <button id="openFilterNavBtn" class="footer-btn footer-nav-btn" type="button"><b>⌕</b><span>院校库</span></button>
      <button id="prepNavBtn" class="footer-btn footer-nav-btn" type="button"><b>◷</b><span>备考</span></button>
      <button id="practiceNavBtn" class="footer-btn footer-nav-btn" type="button"><b>▤</b><span>题库</span></button>
      <button id="profileNavBtn" class="footer-btn footer-nav-btn" type="button"><b>♙</b><span>我的</span></button>
    </footer>
  `}function a(){return`
    <div class="detail-overlay hidden" id="detailPage">
      <div class="detail-content">
        <div class="detail-hero" id="detailHero">
          <button class="detail-back" id="detailBackBtn" type="button" aria-label="返回">←</button>
          <button class="detail-photo-btn" id="detailPhotoBtn" type="button">◉ 校园实景</button>
          <button class="detail-fav-btn" id="detailFavBtn" type="button" aria-label="收藏" title="收藏">☆</button>
          <div class="hero-content"><h2 id="detailName">院校名称</h2><div class="hero-badges" id="detailBadges"></div></div>
        </div>
        <section id="detailMatchSummary" class="detail-match-summary"></section>

        <section class="detail-section detail-score-section"><div class="detail-section-heading"><h3 class="detail-section-title"><i>♬</i> 录取节奏</h3><span class="section-note">近 4 年</span></div><div class="score-table-wrap"><table class="score-table"><thead><tr><th>年份</th><th>国家线</th><th>院校线</th><th>你的分数</th><th>差值</th></tr></thead><tbody id="detailScoreTable"></tbody></table></div><div class="detail-verdict" id="detailVerdict"></div></section>

        <section class="detail-section" id="detailRetestSection" style="display:none;"><div class="detail-section-heading"><h3 class="detail-section-title"><i>▣</i> 复试基础线</h3><span class="section-note">2026 年</span></div><p class="detail-nl-note">复试基本分数线参考（国家线 + 院校预估）</p><div class="retest-grid" id="detailRetestGrid"></div></section>

        <section class="detail-section" id="detailRequirementsSection" style="display:none;"><div class="detail-section-heading"><h3 class="detail-section-title"><i>⚙</i> 硬性报考要求</h3><span class="section-note">招生简章要点</span></div><div class="requirements-grid" id="detailRequirementsGrid"></div></section>

        <section class="detail-section detail-info-section"><div class="detail-section-heading"><h3 class="detail-section-title">院校档案</h3><span class="section-note">招生分区与位置</span></div><div class="detail-info-row" id="detailInfo"></div></section>

        <section class="detail-section"><div class="detail-section-heading"><h3 class="detail-section-title"><i>♧</i> 优势与不足</h3><span class="section-note">择校参考</span></div><div class="pros-cons-grid"><div class="pros-column"><h4>✓ 优势</h4><ul id="detailPros"></ul></div><div class="cons-column"><h4>△ 不足</h4><ul id="detailCons"></ul></div></div></section>

        <section class="detail-section detail-photos-section"><div class="detail-section-heading"><h3 class="detail-section-title"><i>▣</i> 校园风光</h3><span class="section-note">4 张美景 ›</span></div><div class="photo-grid" id="detailPhotos"></div></section>

        <section class="detail-section detail-about-section"><div class="detail-section-heading"><h3 class="detail-section-title"><i>⌂</i> 院校简介</h3><span class="section-note">Tsinghua University</span></div><p class="detail-features" id="detailFeatures"></p></section>
      </div>
    </div>
  `}function o(){return`
    <div class="modal-overlay hidden" id="editModal">
      <div class="modal-content">
        <div class="modal-header"><h3>管理院校数据</h3><div class="modal-header-actions"><button class="modal-export" id="exportDataBtn" type="button">导出备份</button><button class="modal-close" id="closeModalBtn" type="button" aria-label="关闭">✕</button></div></div>
        <div class="modal-body">
          <div class="modal-tabs"><button class="modal-tab active" type="button" data-tab="universities">院校列表</button><button class="modal-tab" type="button" data-tab="add">添加院校</button><button class="modal-tab" type="button" data-tab="import">导入数据</button></div>
          <div class="modal-tab-content" id="tabUniversities"><input type="text" id="uniSearchInput" class="form-input" placeholder="搜索院校名称..."><div id="uniList" class="uni-edit-list"></div></div>
          <div class="modal-tab-content hidden" id="tabAdd"><form id="addUniForm" class="add-uni-form"><input type="text" id="addName" class="form-input" placeholder="院校名称 *" required><input type="text" id="addProvince" class="form-input" placeholder="所在省份 *" required><input type="text" id="addCity" class="form-input" placeholder="所在城市"><select id="addZone" class="form-select" aria-label="招生分区"><option value="A">A区</option><option value="B">B区</option></select><select id="addLevel" class="form-select" aria-label="院校层次"><option value="双非">双非院校</option><option value="211">211</option><option value="985">985</option><option value="双一流">双一流</option></select><textarea id="addScores" class="form-textarea" placeholder="录取分数(JSON格式)&#10;例如: {&quot;工学-学硕&quot;: {&quot;2024&quot;: 320, &quot;2023&quot;: 315, &quot;2022&quot;: 310}}"></textarea><button type="submit" class="btn-primary">添加/更新院校</button></form></div>
          <div class="modal-tab-content hidden" id="tabImport"><p class="import-hint">粘贴JSON数据批量导入院校和分数线</p><textarea id="importDataText" class="form-textarea large" placeholder="粘贴JSON数据..."></textarea><button id="importBtn" class="btn-primary" type="button">批量导入</button><p id="importResult" class="import-result"></p></div>
        </div>
      </div>
    </div>
  `}function s(){return`
    <section id="prepScreen" class="app-screen prep-screen" aria-label="备考">
      <header class="study-topbar"><div><h1>备考</h1><p>计划、专注与复习节奏</p></div><button id="prepSettingsBtn" class="study-icon-btn" type="button" aria-label="备考设置">⚙</button></header>
      <main class="study-main">
        <section class="prep-countdown-card" aria-label="初试倒计时">
          <div><span>距离 <span id="prepExamYear">—</span> 考研</span><strong id="prepDaysLeft">—</strong><em>天</em></div>
          <b id="prepStage">待确认计划</b>
          <p>本周任务 <i id="prepWeekProgress">—</i><small><u></u></small></p>
        </section>
        <section class="today-action-card" aria-labelledby="todayActionTitle">
          <div class="today-action-head"><div><h2 id="todayActionTitle">今天该干什么</h2><small id="prepNextMilestone">登录后根据计划同步节点</small></div><b id="prepCompletionRate">—</b></div>
          <div class="today-metrics"><span><small>今日学习</small><strong id="prepStudyTime">登录后同步 / 8h</strong></span><span><small>任务完成</small><strong id="prepTaskProgress">—</strong></span></div>
          <div class="today-actions"><button id="startStudyBtn" type="button">▷ 开始学习</button><button id="dailyCheckinBtn" type="button" title="当前仅保存在本机">✓ 本机打卡</button></div>
          <p>✦ 完成今天，比计划明天更重要。</p>
        </section>
        <section class="prep-shortcuts" aria-label="备考功能"><button type="button"><i>▣</i><strong>计划</strong><small>年 / 月 / 周</small></button><button id="openTimerBtn" class="is-dark" type="button"><i>◷</i><strong>计时</strong><small>开始专注</small></button><button type="button"><i>文</i><strong>单词</strong><small>待接入词库</small></button></section>
        <section class="study-section prep-tasks-section" aria-labelledby="prepTasksTitle"><div class="study-section-heading"><h2 id="prepTasksTitle">今日任务</h2><button type="button">管理计划</button></div><div id="prepTaskList" class="prep-task-list"><button class="prep-task" type="button" data-task-id="english"><span class="prep-task-check"></span><span><small class="english-subject">英语</small><strong>核心词汇 200</strong></span><em>25分钟</em></button><button class="prep-task is-complete" type="button" data-task-id="math"><span class="prep-task-check">✓</span><span><small class="math-subject">数学</small><strong>高数强化 · 多元积分</strong></span><em>120分钟</em></button><button class="prep-task" type="button" data-task-id="politics"><span class="prep-task-check"></span><span><small class="politics-subject">政治</small><strong>肖1000 · 60题</strong></span><em>45分钟</em></button><button class="prep-task" type="button" data-task-id="major"><span class="prep-task-check"></span><span><small class="major-subject">专业课</small><strong>数据结构 · 图</strong></span><em>90分钟</em></button></div></section>
        <button id="prepStatsBtn" class="study-ai-tip study-ai-entry" type="button"><b>✦</b><span><strong>AI 学习顾问</strong><small>登录后会结合你的学习记录与计划给出建议。</small></span><em>去聊聊 ↗</em></button>
      </main>
    </section>
  `}function c(){return`
    <section id="myScreen" class="app-screen my-screen" aria-label="我的">
      <header class="my-profile-head"><span id="myProfileAvatar">♙</span><div><h1 id="myProfileName">未登录</h1><p id="myProfileMeta">登录后同步你的备考数据</p></div><button id="myEditTargetBtn" type="button" aria-label="设置">⚙</button></header>
      <main class="study-main my-main">
        <section id="myAuthCard" class="my-auth-card" aria-label="账号与云端同步" data-auth-state="signed-out">
          <div class="my-auth-copy">
            <span class="my-auth-eyebrow">账号与云端同步</span>
            <strong id="myAuthTitle">登录后，学习数据不会丢</strong>
            <small id="myAuthDescription">跨设备同步目标院校、学习计划与 AI 建议。</small>
          </div>
          <div class="my-auth-actions">
            <button id="myOpenAuthBtn" class="my-auth-open-btn" type="button" aria-controls="myAuthForm">登录 / 注册</button>
            <button id="myLogoutBtn" class="my-auth-logout-btn" type="button" hidden>退出登录</button>
          </div>
          <form id="myAuthForm" class="my-auth-form hidden" data-mode="register" aria-describedby="myAuthStatus myAuthError">
            <div class="my-auth-form-heading">
              <div>
                <span class="my-auth-form-kicker">安全同步账号</span>
                <strong class="my-auth-mode-title my-auth-mode-title-register">创建你的备考账号</strong>
                <strong class="my-auth-mode-title my-auth-mode-title-login">欢迎回来</strong>
              </div>
              <span class="my-auth-security-mark" aria-label="账号数据加密保护">加密保护</span>
            </div>
            <p id="myAuthStatus" class="my-auth-status" role="status" aria-live="polite">使用昵称和密码登录；注册后即可同步学习数据。</p>
            <div class="my-auth-fields">
              <label class="my-auth-field" for="myAuthNameInput">
                <span class="my-auth-field-label">昵称 / 用户名</span>
                <input id="myAuthNameInput" name="username" type="text" minlength="2" maxlength="32" autocomplete="username" spellcheck="false" placeholder="例如：小研同学" aria-describedby="myAuthUsernameHint myAuthError" required>
                <small id="myAuthUsernameHint" class="my-auth-field-hint">2–32 位中文、字母、数字、下划线或连字符</small>
              </label>
              <label class="my-auth-field" for="myAuthPasswordInput">
                <span class="my-auth-field-label">密码</span>
                <input id="myAuthPasswordInput" name="password" type="password" minlength="8" maxlength="128" autocomplete="new-password" placeholder="至少 8 位" aria-describedby="myAuthPasswordHint myAuthError" required>
                <small id="myAuthPasswordHint" class="my-auth-field-hint">请设置 8–128 位密码</small>
              </label>
              <label id="myAuthEmailRow" class="my-auth-field my-auth-email-field" for="myAuthAccountInput">
                <span class="my-auth-field-label">邮箱 <em>可选</em></span>
                <input id="myAuthAccountInput" name="email" type="email" maxlength="120" autocomplete="email" inputmode="email" placeholder="用于找回账号与接收提醒" aria-describedby="myAuthEmailHint myAuthError">
                <small id="myAuthEmailHint" class="my-auth-field-hint">仅用于账号服务，不会公开展示</small>
              </label>
            </div>
            <p id="myAuthError" class="my-auth-error" role="alert" aria-live="assertive" aria-atomic="true" hidden></p>
            <div class="my-auth-form-actions">
              <button id="myAuthSubmitBtn" class="my-auth-submit-btn" type="submit" data-loading-text="注册中…">注册并登录</button>
              <button id="myAuthSwitchBtn" class="my-auth-switch-btn" type="button">已有账号，去登录</button>
            </div>
            <button id="myCloseAuthBtn" class="my-auth-close-btn" type="button">暂不登录，先浏览</button>
          </form>
        </section>
        <section class="my-target-snapshot" aria-label="报考方案"><div><small id="myTargetPlanLabel">本机目标档案</small><strong id="myTargetUniversity">北京邮电大学 · 软件工程</strong><p><span id="myTargetScore">365</span> 分 <i id="myTargetDegree">学硕</i> · <i id="myTargetCategory">工学</i></p></div><b id="myTargetPlanCode">083500</b></section>
        <section class="my-favorites-section" aria-labelledby="myFavoritesTitle">
          <header class="my-favorites-heading"><div><small>云端收藏</small><h2 id="myFavoritesTitle">收藏院校 <b id="myFavCount">0</b></h2></div><span id="myFavSyncStatus">登录后同步</span></header>
          <div id="myFavList" class="my-favorites-list"><p id="myFavEmpty" class="my-favorites-empty">登录后可跨设备保存收藏院校。</p></div>
        </section>
        <section class="my-week-card"><small>本周学习</small><div><strong id="myWeekStudyTime">—</strong><em id="myWeekDailyAverage">登录后同步</em></div><div class="my-bars" aria-label="学习趋势"><i></i><i></i><i></i><i></i><i></i><i class="active"></i><i></i></div></section>
        <section class="my-metric-grid"><span><b id="myWeekSessionCount">—</b><small>本周记录</small></span><span><b id="myPlanSyncStatus">未同步</b><small>计划状态</small></span><span><b id="myTodayStudyTime">—</b><small>今日学习</small></span></section>
        <section class="my-subject-section"><h2>学科投入</h2><div id="mySubjectList" class="my-subject-list"><p><span>登录后</span><i><b style="width:0%"></b></i><em>—</em></p></div></section>
        <section class="my-quick-grid" aria-label="个人功能"><button id="myOpenDataBtn" type="button"><b>⌂</b><span>目标院校</span></button><button id="myExportBtn" type="button"><b>▥</b><span>学习报告</span></button><button id="myShareBtn" type="button"><b>♧</b><span>分享应用</span></button><button id="myFeedbackBtn" type="button"><b>◌</b><span>通知</span></button></section>
        <section class="my-demo-note" aria-label="数据同步状态"><b>✦</b><span><strong id="myDataSourceTitle">云端数据待连接</strong><small id="myDataSourceText">登录后，学习记录、计划与 AI 建议会同步到你的账号。</small></span><button id="themeToggleBtn" type="button">☾ 夜间</button></section>
        <div class="my-data-compat" aria-hidden="true"><div id="myHistoryList"><div id="myHistoryEmpty"></div></div><button id="myClearHistoryBtn" type="button"></button><button id="myOpenDataBtn2" type="button"></button></div>
      </main>
    </section>
  `}function l(){return`
    <section id="practiceScreen" class="app-screen practice-screen" aria-label="题库">
      <header class="study-topbar">
        <div><h1>题库</h1><p>真题、刷题、单词与错题闭环</p></div>
        <button class="study-icon-btn" type="button" aria-label="搜索题库">⌕</button>
      </header>
      <main class="study-main">
        <button id="resumePracticeBtn" class="practice-resume" type="button">
          <span class="practice-ring">85%</span>
          <span><small>继续上次练习</small><strong>2022 英语一 · 阅读</strong><em>二刷 · 34 / 40 · 还剩 2 篇</em></span><b>›</b>
        </button>
        <section class="practice-entry-grid" aria-label="题库功能">
          <button type="button" data-practice-action="历年真题"><i>▤</i><strong>历年真题</strong><small>英语一 · 2010—2026</small></button>
          <button type="button" data-practice-action="专项刷题"><i>✓</i><strong>专项刷题</strong><small>按知识点智能组卷</small></button>
          <button type="button" data-practice-action="错题本"><i>×</i><strong>错题本</strong><small>126 题待复习</small></button>
          <button type="button" data-practice-action="单词系统"><i>文</i><strong>单词系统</strong><small>今日 120 / 200</small></button>
        </section>
        <section class="study-section" aria-labelledby="wrongReviewTitle">
          <div class="study-section-heading"><h2 id="wrongReviewTitle">今日错题复习</h2><button id="allWrongBtn" type="button">查看全部</button></div>
          <div class="practice-wrong-list">
            <button type="button"><i class="math"></i><span><strong>极限与连续</strong><small>数学 · 高数 · 计算错误</small></span><em>12题</em></button>
            <button type="button"><i class="english"></i><span><strong>长难句理解</strong><small>英语 · 阅读 · 知识点不熟</small></span><em>8题</em></button>
            <button type="button"><i class="politics"></i><span><strong>唯物辩证法</strong><small>政治 · 马原 · 审题错误</small></span><em>6题</em></button>
          </div>
        </section>
        <button id="wrongAnalysisBtn" class="study-ai-tip" type="button"><b>✦</b><span><strong>AI 错题分析</strong><small>本月数学 36% 的错误来自计算失误，建议开启限时验算训练。</small></span></button>
      </main>
    </section>
  `}function u(){return`
    <section id="agentChatScreen" class="app-screen agent-screen" aria-label="AI 考研复习规划教练">
      <header class="agent-topbar">
        <button id="agentChatBackBtn" class="agent-round-btn" type="button" aria-label="返回备考">←</button>
        <div><h1>考研复习规划教练</h1><p id="agentChatStatus">登录后同步云端学习数据</p></div>
        <button class="agent-round-btn" type="button" aria-label="更多操作">•••</button>
      </header>
      <main class="agent-main">
        <section class="agent-context"><div><b>教练正在结合你的云端数据给建议</b><small>登录后同步</small></div><p><span>近 30 天 —</span><span>— 条学习记录</span><span>暂未记录</span></p></section>
        <div id="agentMessages" class="agent-messages" aria-live="polite">
          <article class="agent-message is-assistant"><i>✦</i><p>登录后可以开始一段会保存到云端的考研规划对话。</p></article>
        </div>
        <p class="agent-quick-label">从这里开始</p>
        <div class="agent-quick-actions"><button type="button" data-agent-prompt="请帮我建立考研备考档案，并告诉我还需要补充哪些信息。" data-agent-proposal-type="study">建立备考档案</button><button type="button" data-agent-prompt="请结合我的学习记录，帮我做一次本周复盘。" data-agent-proposal-type="study">本周复盘</button><button type="button" data-agent-prompt="请结合我的云端计划和收藏院校，给出报考方案建议。" data-agent-proposal-type="admission">择校建议</button></div>
        <form id="agentChatForm" class="agent-composer"><input id="agentChatInput" maxlength="300" placeholder="例如：我还有 180 天，数学基础较弱…" aria-label="输入给考研复习规划教练的问题"><button type="submit" aria-label="发送消息">↑</button></form>
        <p class="agent-disclaimer">建议基于已同步数据生成；招生政策请以院校官网和研招网为准。</p>
      </main>
    </section>
    <section id="agentProposalScreen" class="app-screen agent-screen" aria-label="AI 学习计划提案">
      <header class="agent-topbar">
        <button id="agentProposalBackBtn" class="agent-round-btn" type="button" aria-label="返回对话">←</button>
        <div><h1>考研复习规划教练</h1><p>基于你的备考数据给出建议</p></div>
        <span id="agentStatus" class="agent-status">✦ 待同步</span>
      </header>
      <main class="agent-main">
        <section class="agent-week-summary"><div><small>近 7 天云端数据</small><h2 id="agentWeekHeadline">登录后生成个性化建议</h2></div><span id="agentWeekRange">等待同步</span><dl><div><dt>学习时长</dt><dd id="agentWeekStudyTime">—</dd><small id="agentWeekStudyMeta">登录后同步</small></div><div><dt>学习记录</dt><dd id="agentWeekSessionCount">—</dd><small id="agentWeekSessionMeta">等待同步</small></div><div><dt>投入最多</dt><dd id="agentWeekPriority">—</dd><small id="agentWeekPriorityMeta">暂无数据</small></div></dl></section>
        <button id="agentOpenChatBtn" class="agent-consult-entry" type="button"><i>✦</i><span><b>考研复习规划教练</b><small>先补齐目标，再生成周计划与复盘建议</small></span><em>去聊聊 ↗</em></button>
        <section class="agent-proposal-card"><header><div><h2 id="agentProposalTitle">下周学习计划</h2><p id="agentProposalMeta">生成后会先等待你的确认</p></div><b id="agentProposalBadge">待生成</b></header><p id="agentProposalRationale" class="agent-proposal-rationale">先和 AI 顾问聊聊，再主动生成一份可确认、可同步的计划。</p><div id="agentPlanItems" class="agent-plan-items"></div></section>
        <div class="agent-proposal-actions"><button id="agentApplyProposalBtn" class="agent-apply-btn" type="button">✓ 应用这份计划</button><button id="agentAdjustProposalBtn" class="agent-adjust-btn" type="button">调整后再应用</button></div>
        <p class="agent-disclaimer">应用后将同步更新备考页；你可以随时手动编辑。</p>
      </main>
    </section>
  `}function d(d=document.getElementById(`app`)){if(!d)throw Error(`应用挂载节点 #app 不存在`);d.innerHTML=[e(),t(),n(),s(),l(),c(),u(),r(),i(),a(),o()].join(``)}var f=`modulepreload`,p=function(e,t){return new URL(e,t).href},m={};d(),function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e=document.getElementsByTagName(`link`),i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}function s(e){return import.meta.resolve?import.meta.resolve(e):new URL(e,import.meta.url).href}r=o(t.map(t=>{if(t=p(t,n),t=s(t),t in m)return;m[t]=!0;let r=t.endsWith(`.css`);for(let n=e.length-1;n>=0;n--){let i=e[n];if(i.href===t&&(!r||i.rel===`stylesheet`))return}let i=document.createElement(`link`);if(i.rel=r?`stylesheet`:f,r||(i.as=`script`),i.crossOrigin=``,i.href=t,a&&i.setAttribute(`nonce`,a),document.head.appendChild(i),r)return new Promise((e,n)=>{i.addEventListener(`load`,e),i.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${t}`)))})}))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})}(()=>import(`./app-B6C2wD0M.js`),__vite__mapDeps([0,1,2]),import.meta.url);